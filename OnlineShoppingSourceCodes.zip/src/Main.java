import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        UserManagement userManagement = new UserManagement();
        OrderManager orderManager = new OrderManager();
        int choice = 0;
        int orderId = 0;
        Scanner scanner = new Scanner(System.in);

        Product prod1 = new Product("Stereo", "music", 14.99);
        Product prod2 = new Product("Barbie", "toy", 20.99);
        Product prod3 = new Product("Batman", "toy", 18.99);
        Product prod4 = new Product("Popcorn", "food", 7.99);
        Product prod5 = new Product("Pandora", "music", 65.99);
        Product prod6 = new Product("Icecream", "food", 8.99);

        ProductCatalog catalog = new ProductCatalog();
        catalog.addProduct(prod1);
        catalog.addProduct(prod2);
        catalog.addProduct(prod3);
        catalog.addProduct(prod4);
        catalog.addProduct(prod5);
        catalog.addProduct(prod6);

        System.out.println("Welcome to the Big Online Shopping Platform!!!");
        System.out.println("Choose an option below to get started!");
        while(choice != 4){
            System.out.println("1. Create a new User Account");
            System.out.println("2. Log in to an existing User Account");
            System.out.println("3. Manager Orders");
            System.out.println("4. Exit");

            choice = scanner.nextInt();
            switch(choice){
                case 1:
                    boolean success = false;
                    System.out.println("Please create a username and password for your account");
                    while(!success) {
                        System.out.println("Username: ");
                        String username = scanner.next();
                        System.out.println("Password:");
                        String password = scanner.next();

                        User user = new User(username, password, catalog);
                        success = userManagement.registerUser(user.getUsername(), user.getHashedPassword());
                        if(success){
                            System.out.println("User account successfully created!");
                            System.out.println(user);
                        }
                        else
                            System.out.println("Username already exists, please choose a different username.\n");
                    }
                    break;
                case 2:
                    System.out.println("Please enter a valid username and password to log in: ");
                    System.out.println("Username: ");
                    String username = scanner.next();
                    System.out.println("Password: ");
                    String password = scanner.next();
                    User currUser = new User(username, password, catalog);

                    success = userManagement.authenticateUser(currUser.getUsername(), currUser.getHashedPassword());
                    if(!success)
                        System.out.println("Could not authenticate user, please try again");
                    else {
                        System.out.println("You have successfully logged in!");
                        int option = 0;
                        ShoppingCart currCart;
                        while(option != 6) {
                            currCart = currUser.getShoppingCart();
                            System.out.println("1. Add a product into your cart");
                            System.out.println("2. Remove product from cart");
                            System.out.println("3. Print total price of products in your cart");
                            System.out.println("4. See recommendations");
                            System.out.println("5. Search for products");
                            System.out.println("6. Cash Out Account");
                            option = scanner.nextInt();
                            switch(option){
                                case 1:
                                    System.out.println(catalog.getAllProducts());
                                    System.out.println("Which product would you like? Please enter the name:");
                                    String add = scanner.next();
                                    currCart.addProduct(add);
                                    break;
                                case 2:
                                    System.out.println(currCart.getProducts());
                                    System.out.println("Which product do you want to remove?");
                                    String remove = scanner.next();
                                    currCart.removeProduct(remove);
                                    break;
                                case 3:
                                    System.out.println("Current total price in your cart: " + currCart.calculateTotalPrice());
                                    break;
                                case 4:
                                    RecommendationSystem recommend = new RecommendationSystem(catalog);
                                    ArrayList<Product> recommendations = recommend.generateRecommendations(currUser);
                                    System.out.println("Recommended Products: ");
                                    System.out.println(recommendations);
                                    break;
                                case 5:
                                    System.out.println("Would you like to search by price range, description, or name?");
                                    System.out.println("1. Price, 2. Description, 3.Name");
                                    int search = scanner.nextInt();
                                    if(search == 1){
                                        System.out.println("What is your min and max price range?");
                                        System.out.println("Min: ");
                                        double min = scanner.nextDouble();
                                        System.out.println("Max: ");
                                        double max = scanner.nextDouble();
                                        System.out.println(catalog.searchByPriceRange(min, max));

                                    }
                                    else if(search == 2){
                                        System.out.println("What kind of product is it?");
                                        String category = scanner.next();
                                        System.out.println(catalog.getByDescription(category));
                                    }
                                    else if(search == 3){
                                        System.out.println("What is the name of your product?");
                                        String name = scanner.next();
                                        System.out.println(catalog.searchByName(name));
                                    }

                                    System.out.println("And all products sorted by price: ");
                                    catalog.sortProductsByPrice();
                                    System.out.println(catalog.getAllProducts());
                                    break;
                                case 6:
                                    orderId++;
                                    Order currOrder = new Order(orderId, currUser, currCart.getProducts());
                                    System.out.println("Order being archived: ");
                                    System.out.println(currOrder);
                                    orderManager.addOrder(currOrder);
                                    break;
                            }

                        }
                    }
                    break;
                case 3:
                    System.out.println("What Order would you like to search for?");
                    System.out.println("Order Id: ");
                    int id = scanner.nextInt();

                    Order currOrder = orderManager.getOrderById(id);
                    System.out.println(currOrder);

                    System.out.println("Full order tree: ");
                    orderManager.printOrders();
                    break;
            }
        }
        System.out.println("Have a good day");

    }
}