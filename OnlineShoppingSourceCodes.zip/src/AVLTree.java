//Name: Kiara Matos-Luna

public class AVLTree{
    //Public Class made in AVLTree with nodes for each vertex of the tree
    public class Node {
        //Attributes of Node Class
        Order data;
        Node left, right;
        int height;

        //Constructor
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        public Node(Order data) {
            this.data = data;
            this.height = 1; // Initial height is 1
        }
    }
    //Time Complexity: O(1)
    //Space Comlexity: O(1)
    public Node getRoot() {
        return root;
    }

    //Public Node attribute for AVLTree class
    public Node root;

    // Insert a new node into the AVL tree
    //Time Complexity: The time complexity of the insert method is O(log n) in the average case and O(n)
    // in the worst case, where n is the number of nodes in the binary search tree. This is because the method
    // recursively traverses the tree to find the correct position to insert the new order,
    // and the height of a balanced binary search tree is log n. However, in the worst case scenario
    // where the tree is unbalanced (e.g. if the orders are inserted in sorted order), the time complexity
    // becomes O(n) as the tree degenerates into a linked list.
    //Space Complexity: The space complexity of the insert method is O(log n) in the average
    // case and O(n) in the worst case. This is because the method uses recursion to traverse the tree,
    // and the maximum depth of the recursion stack is equal to the height of the tree, which is log n
    // for a balanced tree. In the worst case scenario of a degenerate tree, the space complexity
    // becomes O(n) as the recursion stack grows linearly with the number of nodes in the tree.
    public void insert(Order order) {
        root = insert(root, order);
    }

    // Recursive method to insert a new node
    //Time Complexity: Best Case O(log n) and worst case O(n) where n is the number of nodes in the tree.
    //For the best case in  balanced binary search tree the height of the tree is log n
    //Worst case scenario where the tree is skewed instead of balanced, the height becomes n
    //Space Complexity: Best Case O(log n) and worst case O(n) since space complexity is determined by the height
    //of the tree, which is log n in a balanced tree and n in a skewed tree.
    private Node insert(Node node, Order data) {
        if (node == null) {
            return new Node(data);
        }

        // Insert data based on its comparison with current node
        if (data.getTotalPrice() < node.data.getTotalPrice()) {
            node.left = insert(node.left, data);
        } else if (data.getTotalPrice() > node.data.getTotalPrice()) {
            node.right = insert(node.right, data);
        }else {
            // Duplicate price, do not insert again
            return node;
        }

        // Update height of current node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Check and balance the AVL tree
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        int balance = getBalance(node);

        // Left Left Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance > 1 && node.left.data.getTotalPrice() > node.data.getTotalPrice()) {
            return rightRotate(node);
        }

        // Right Right Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance < -1 && node.right.data.getTotalPrice() < node.data.getTotalPrice()) {
            return leftRotate(node);
        }

        // Left Right Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance > 1 && node.left.data.getTotalPrice() < node.data.getTotalPrice()) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Right Left Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance < -1 && node.right.data.getTotalPrice() > node.data.getTotalPrice()) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    // Get height of a node
    //Time Complexity: O(1) simple arithmetic and single comparison
    //Space Complexity: O(1) takes constant amount of space to store the integer value
    private int height(Node node) {
        if (node == null) {
            return 0;
        }
        return node.height;
    }

    // Get balance factor of a node
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    private int getBalance(Node node) {
        if (node == null) {
            return 0;
        }
        return height(node.left) - height(node.right);
    }

    // Perform left rotation
    //Time Complexity: O(1) with fixed number of operations regardless of size of tree
    //Space Complexity: O(1) does not depend on input size
    private Node leftRotate(Node node) {
        if (node == null || node.right == null) {
            // Null check: If the node or its right child is null, return the node itself
            return node;
        }
        Node rightChild = node.right;
        Node leftOfRightChild = rightChild.left;

            // Perform rotation
        rightChild.left = node;
        node.right = leftOfRightChild;


        // Update heights
        node.height = 1 + Math.max(height(node.left), height(node.right));
        rightChild.height = 1 + Math.max(height(rightChild.left), height(rightChild.right));


        // Return new root
        return rightChild;
    }

    // Perform right rotation
    //Time Complexity: O(1) with fixed number of operations regardless of size of tree
    //Space Complexity: O(1) does not depend on input size
    private Node rightRotate(Node node) {
        if (node == null || node.left == null) {
            // Null check: If the node or its left child is null, return the node itself
            return node;
        }
        Node leftChild = node.left;
        Node rightOfLeftChild = leftChild.right;

        // Perform rotation
        leftChild.right = node;
        node.left = rightOfLeftChild;

        // Update heights
        node.height = 1 + Math.max(height(node.left), height(node.right));
        leftChild.height = 1 + Math.max(height(leftChild.left), height(leftChild.right));

        // Return new root
        return leftChild;
    }
    //Method to return the node with the smallest value
    //Time Complexity: Best Case O(log n) and worst case O(n) where n is the number of nodes in the tree
    //In the best case scenario, the method will traverse down the left subtree of the tree until it reaches the
    //leftmost node. In the worst case scenario where the tree is unbalanced, the method will have to traverse
    //through all the nodes in the tree.
    //Space Complexity: O(1) constant amount of extra space regardless of input size
    private Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }
    //Time Complexity: The time complexity of the delete operation in a binary search tree is
    // O(log n) in the average case and O(n) in the worst case. This is because in the average case,
    // the delete operation involves traversing the height of the tree, which is O(log n) in a balanced tree.
    // However, in the worst case scenario where the tree is unbalanced, the delete operation may involve
    // traversing all the nodes in the tree, resulting in a time complexity of O(n).
    //Space Complexity: The space complexity of the delete operation is O(log n) in the average case
    // and O(n) in the worst case. This is because the space required for the recursive calls in
    // the delete operation is proportional to the height of the tree, which is O(log n) in a
    // balanced tree. However, in the worst case scenario where the tree is unbalanced, the space
    // complexity may be O(n) due to the recursive calls potentially reaching all nodes in the tree.
    public void delete(Order data) {
        root = delete(root, data);
    }

    // Recursive method to delete a node
    //Time complexity: The time complexity of the delete method in a binary search tree is O(log n)
    // in the average case and O(n) in the worst case. This is because in a balanced binary search tree,
    // the height of the tree is log n, where n is the number of nodes in the tree. However, in the worst
    // case scenario where the tree is skewed, the height of the tree becomes n, resulting in a time complexity
    // of O(n).
    //Space Complexity: The space complexity of the delete method is O(log n) in the average case
    // and O(n) in the worst case. This is because the space used by the recursive calls on the
    // call stack is proportional to the height of the tree, which is log n in a balanced tree
    // and n in a skewed tree.
    private Node delete(Node node, Order data) {
        if (node == null) {
            return node;
        }

        // Delete data based on its comparison with current node
        if (data.getTotalPrice() < node.data.getTotalPrice()) {
            node.left = delete(node.left, data);
        } else if (data.getTotalPrice() > node.data.getTotalPrice()) {
            node.right = delete(node.right, data);
        } else {
            // Node with only one child or no child
            if (node.left == null || node.right == null) {
                Node temp = null;
                if (temp == node.left) {
                    temp = node.right;
                } else {
                    temp = node.left;
                }

                // No child case
                if (temp == null) {
                    temp = node;
                    node = null;
                } else { // One child case
                    node = temp;
                }
            } else {
                // Node with two children: Get the inorder successor (smallest in the right subtree)
                Node temp = minValueNode(node.right);

                // Copy the inorder successor's data to this node
                node.data = temp.data;

                // Delete the inorder successor
                node.right = delete(node.right, temp.data);
            }
        }

        // If the tree had only one node, then return
        if (node == null) {
            return node;
        }

        // Update height of current node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Check and balance the AVL tree
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        int balance = getBalance(node);

        // Left Left Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance > 1 && getBalance(node.left) >= 0) {
            return rightRotate(node);
        }

        // Left Right Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance > 1 && getBalance(node.left) < 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Right Right Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance < -1 && getBalance(node.right) <= 0) {
            return leftRotate(node);
        }

        // Right Left Case
        //Time Complexity: O(1)
        //Space Complexity: O(1)
        if (balance < -1 && getBalance(node.right) > 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    // Method to print the AVL tree (depth-first traversal)
    //Time Complexity: O(n)
    //Space Complexity: O(n)
    public void print() {
        print(root);
    }

    // Recursive method to print the AVL tree with depth-first traversal
    //The time complexity of this print method is O(n), where n is the number of nodes in the binary tree.
    // This is because the method visits each node exactly once in a depth-first traversal.
    //The space complexity of this print method is also O(n) due to the recursive calls on the stack.
    // In the worst case scenario, where the binary tree is skewed and has a height of n,
    // the method will make n recursive calls before reaching the base case.
    // This results in O(n) space complexity.
    private void print(Node node) {
        if (node != null) {
            print(node.left);
            System.out.print(node.data + " ");
            print(node.right);
        }
    }
}
