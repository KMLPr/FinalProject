//Name: Kiara Matos-Luna
import java.util.ArrayList;

public class ProductCatalog {
    //Using an ArrayList due to constant time complexity for adding and removing a product
    //Time Complexity: O(n) where n is the number of products in the array list for the traversal and search methods
    //Attribute
    private ArrayList<Product> products;

    //Constructor
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public ProductCatalog() {
        products = new ArrayList<>();
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public ArrayList<Product> getProducts(){
        return products;
    }
    // Heap sort implementation for sorting products by price
    //Time Complexity: O(n log n) where n is the number of products in the list. Building the max heap takes O(n) time
    //and heapifying the heap in a heap sort process takes O(log n) for each element.
    //Space Complexity: O(n) where n is the number of products in the list. An array of size n is created to store
    //the products for sorting.
    public void sortProductsByPrice() {
        if (products.size() < 2) {
            return; // No need to sort if there are 0 or 1 products
        }
        // Convert the list to an array for in-place sorting
        Product[] productsArray = products.toArray(new Product[products.size()]);

        // Build max heap
        for (int i = productsArray.length / 2 - 1; i >= 0; i--) {
            heapify(productsArray, productsArray.length, i);
        }

        // Heap sort
        for (int i = productsArray.length - 1; i > 0; i--) {
            // Swap root (max element) with the last element
            Product temp = productsArray[0];
            productsArray[0] = productsArray[i];
            productsArray[i] = temp;

            // Heapify the reduced heap
            heapify(productsArray, i, 0);
        }

        // Update the original list with sorted products
        products.clear();
        for (Product product : productsArray) {
            products.add(product);
        }
    }

    //Maintain heap property during sorting process
    //Time Complexity: O(log n) where n is the number of elements in the array because it recursively calls
    //itself on a subtree until it reaches the leaf nodes of the heap
    //Space Complexity: O(1)
    private void heapify(Product[] arr, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].getPrice() > arr[largest].getPrice()) {
            largest = left;
        }

        if (right < n && arr[right].getPrice() > arr[largest].getPrice()) {
            largest = right;
        }

        if (largest != i) {
            Product temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;
            heapify(arr, n, largest);
        }
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public void addProduct(Product product) {
        products.add(product);
    }

    //Time Complexity: O(n) where n is the number of products in the list. In the worst case scenario, we will need to
    //iterate through the entire list to find and remove the specified product.
    //Space Complexity: O(1)
    public void removeProduct(Product product){
        products.remove(product);
    }

    //Time Complexity: O(n) where n is the number of products in the list. Iterates through each element of the list
    //to add their string representation to another list.
    //Space Complexity: O(n) since we are making a new ArrayList of String
    public ArrayList<String> getAllProducts() {
        ArrayList<String> productStrings = new ArrayList<>();
        for (Product curr : products) {
            productStrings.add(curr.toString());
        }
        return productStrings;
    }

    //Time Complexity: O(n) where n is the number of products in the list. Iterates through each element of the list
    //to find Products with the same description
    //Space Complexity: O(n) since we are making a new ArrayList of Product
    public ArrayList<Product> getByDescription(String description){
        ArrayList<Product> matchingProducts = new ArrayList<>();
        for (Product product : products) {
            if (product.getDescription().equalsIgnoreCase(description)) {
                matchingProducts.add(product);
            }
        }
        return matchingProducts;
    }

    //Time Complexity: O(n) where n is the number of products in the list. Iterates through each element of the list
    //to find Products in the price range
    //Space Complexity: O(n) since we are making a new ArrayList of Product
    public ArrayList<String> searchByPriceRange(double minPrice, double maxPrice) {
        ArrayList<String> matchingProducts = new ArrayList<>();
        for (Product product : products) {
            if (product.getPrice() >= minPrice && product.getPrice() <= maxPrice) {
                matchingProducts.add(product.toString());
            }
        }
        return matchingProducts;
    }

    //Time Complexity: O(n) where n is the number of products in the list. Iterates through each element of the list
    //to find products with the same name
    //Space Complexity: O(n) since we are making a new ArrayList of Product
    public ArrayList<String> searchByName(String name) {
        ArrayList<String> matchingProducts = new ArrayList<>();
        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                matchingProducts.add(product.toString());
            }
        }
        return matchingProducts;
    }
}
