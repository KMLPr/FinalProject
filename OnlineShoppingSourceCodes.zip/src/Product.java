import java.util.ArrayList;

public class Product {
    //Attributes that will be used in later search methods
    private String name;
    private String description;
    private double price;

    //Constructor
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public Product(String name, String description, double price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    //Getters for the product
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public String getName() {
        return name;
    }
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public String getDescription() {
        return description;
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public double getPrice() {
        return price;
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public void setName(String name) {
        if(!name.isEmpty())
         this.name = name;
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public void setCost(double cost) {
        if(cost > 0)
            this.price = cost;
    }
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public String toString() {
        return "\nProduct Name: " + name +
                "\nDescription: " + description +
                "\nPrice: $" + price +
                "\n";
    }

}
