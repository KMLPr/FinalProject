//Kiara Matos-Luna
import java.util.ArrayList;

public class ShoppingCart {
    //Attributes
    private ArrayList<Product> products;
    private ProductCatalog productCatalog;

    //Constructors
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public ShoppingCart(ProductCatalog productCatalog) {
        this.products = new ArrayList<>();
        this.productCatalog = productCatalog;
    }
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public ShoppingCart(){
        this.products = new ArrayList<>();
        this.productCatalog = new ProductCatalog();
    }

    //Time Complexity:O(n) where n is the number of products in the catalog since the method iterates through all
    //the elements in ProductCatalog to find the product with the specified name
    //Space Complexity: O(1)
    public void addProduct(String productName) {
        // Find the product in the catalog and add it to the cart
        ArrayList<Product> catalogProducts = productCatalog.getProducts();
        for (Product product : catalogProducts) {
            if (product.getName().equalsIgnoreCase(productName)) {
                products.add(product);
                return; // Product found and added, exit loop
            }
        }
        // Product not found in the catalog
        System.out.println("Product not found in the catalog: " + productName);
    }

    //Time Complexity:O(n) where n is the number of products in the list since the method iterates through all
    //the elements in Product ArrayList to find the product with the specified name in the cart
    //Space Complexity: O(1)
    public void removeProduct(String productName) {
        // Find and remove the product from the cart
        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(productName)) {
                products.remove(product);
                return; // Product found and removed, exit loop
            }
        }
        // Product not found in the cart
        System.out.println("Product not found in the cart: " + productName);
    }

    //Time Complexity: O(n) where n is the number of products in the list
    //Space Complexity: O(1)
    public double calculateTotalPrice() {
        double totalPrice = 0.0;
        for (Product product : products) {
            totalPrice += product.getPrice();
        }
        return totalPrice;
    }

    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public ArrayList<Product> getProducts() {
        return products;
    }
}
