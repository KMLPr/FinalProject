//Name: Kiara Matos-Luna
import java.util.ArrayList;
public class Order {
    //Attributes for those class that calls a has-a relation ship with the Product class
    private int orderId;
    private User user;
    private ArrayList<Product> products;
    private double totalPrice;

    // Constructor with the orderId to find the Order
    //Time Complexity: O(n) where n is the number of elements in the ArrayList. The method calls the calculateTotalPrice()
    //method that iterates through the ArrayList, resulting in a linear time complexity
    //Space Complexity: O(1)
    public Order(int orderId, User user, ArrayList<Product> products) {
        this.orderId = orderId;
        this.user = user;
        this.products = products;
        this.totalPrice = calculateTotalPrice(); // Calculate total price based on products
    }

    // Getters and Setters for the attributes needed
    //Time Complexity: O(1) with simple return operation
    //Space Complexity: O(1)
    public int getOrderId() {
        return orderId;
    }

    public User getUser() {
        return user;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public double getTotalPrice() {
        return totalPrice;
    }


    // Calculate total price based on products from the ArrayList<Product>
    //Time Complexity: O(n) where n is the number of products in the ArrayList that is iterated through the loop
    //in a linear time complexity
    //Space Complexity: O(1)
    private double calculateTotalPrice() {
        double totalPrice = 0.0;
        for (Product product : products) {
            totalPrice += product.getPrice();
        }
        return totalPrice;
    }

    //Method to print out the attributes of each Order in a nice and formatted fashion
    //Time Complexity: O(n) where n is the number of products in the order
    //Space Complexity: O(n) where n is the number of products in the order with a new string variable that will
    //grow linearly with the number of products in the order
    public String toString() {
        String line = "";
        line += "Order ID: " + orderId + "\n";
        line += "User: " + user.getUsername() + "\n";
        line += "Products: " + products + "\n";
        line += "Price: " + calculateTotalPrice() + "\n";
        return line;
    }

}
