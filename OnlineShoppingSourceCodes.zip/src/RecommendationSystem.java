//Name: Kiara Matos-Luna
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class RecommendationSystem {
    //Attributes
    private ProductCatalog productCatalog;
    private HashMap<String, ArrayList<Product>> memoizationCache;
    private HashSet<Product> visitedProducts;

    //Constructor
    //Time Complexity: O(1)
    //Space Complexity: O(1)
    public RecommendationSystem(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
        this.memoizationCache = new HashMap<>();
        this.visitedProducts = new HashSet<>();
    }

    // Method to generate recommendations for a given product using memoization
    //Time Complexity: O(n^2) where n is the number of product's in the user shopping cart
    //Space Complexity: O(n^2) because we are creating a new ArrayList to storethe recommendations for each product in the
    //cart and then removing the products already in the cart.
    public ArrayList<Product> generateRecommendations(User user) {
        ArrayList<Product> recommendations = new ArrayList<>();
        for (Product product : user.getShoppingCart().getProducts()) {
            recommendations.addAll(generateRecommendationsForProduct(product));
        }

        recommendations.removeAll(user.getShoppingCart().getProducts());

        return recommendations;
    }

    // Method to generate recommendations for a single product
    //Time Complexity: O(n^2) because for each product we call the getByDescription method which has a time complexity
    //of O(n) where n is the number of products in the catalog. For each similar product found we recursively call
    //the generateRecommendationsForProduct method which iterates through all the products in the catalog.
    //This leads to O(n^2).
    //Space Complexity: O(n) because we are using memoizationCache and visitedProducts to store information about products.
    //The size of these data structures grow linearly with the number of products in the catalog.
    private ArrayList<Product> generateRecommendationsForProduct(Product product) {
        if (product == null || product.getDescription() == null || product.getDescription().isEmpty()) {
            return new ArrayList<>();
        }

        // Check if recommendations for this product are already calculated and cached
        String description = product.getDescription();
        if (memoizationCache.containsKey(description)) {
            return memoizationCache.get(description);
        }

        // Check if the product has been visited before to avoid infinite recursion
        if (visitedProducts.contains(product)) {
            return new ArrayList<>();
        }

        // Mark the current product as visited
        visitedProducts.add(product);

        // Get similar products based on the description
        ArrayList<Product> similarProducts = productCatalog.getByDescription(description);

        // Create a new list to hold the recommendations
        ArrayList<Product> recommendations = new ArrayList<>(similarProducts);

        // Recursively generate recommendations for similar products
        for (Product similarProduct : similarProducts) {
            recommendations.addAll(generateRecommendationsForProduct(similarProduct));
        }
        recommendations.remove(product);

        // Cache the recommendations for future use
        memoizationCache.put(description, recommendations);

        return recommendations;
    }
}
